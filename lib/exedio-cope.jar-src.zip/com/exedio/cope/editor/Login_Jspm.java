
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope.editor;

import static com.exedio.cops.XMLEncoder.encode;

import javax.servlet.http.HttpServletResponse;

final class Login_Jspm
{
	static final void write(
			final StringBuilder out,
			final HttpServletResponse response,
			final Package thePackage,
			final String failureUser)
	{
out.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"  \"http://www.w3.org/TR/html4/loose.dtd\">\n" +
	"<html>\n" +
	"\t<head>\n" +
	"\t\t<meta http-equiv=\"content-type\" content=\"text/html; charset=");
out.append(Editor.UTF8);
out.append("\">\n" +
	"\t\t<title>Live Edit Login</title>\n" +
	"\t\t<style>\n" +
	"\t\t\th1\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-family:sans-serif;\n" +
	"\t\t\t\tfont-size:180%;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg\n" +
	"\t\t\t{\n" +
	"\t\t\t\tborder:0;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg.logo\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfloat:right;\n" +
	"\t\t\t\twidth:198px;\n" +
	"\t\t\t\theight:60px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv.footer\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-size:70%;\n" +
	"\t\t\t}\n" +
	"\t\t</style>\n" +
	"\t</head>\n" +
	"\t<body>\n" +
	"\t\t<a href=\"http://cope.sourceforge.net/\" target=\"_blank\"><img src=\"http://cope.sourceforge.net/exedio.png\" alt=\"Exedio Logo\" class=\"logo\"></a>\n" +
	"\t\t<h1>COPE Live Edit</h1>");

		if(failureUser!=null)
		{
		out.append("\n" +
	"\t\t<div>Login failed, because either user or password was not correct.</div>");

		}
		out.append("\n" +
	"\t\t<form action=\"");
out.append(response.encodeURL(Editor.LOGIN_URL));
out.append("\" method=\"POST\">\n" +
	"\t\t\t<table>\n" +
	"\t\t\t\t<tr>\n" +
	"\t\t\t\t\t<td>Login</td>\n" +
	"\t\t\t\t\t<td><input name=\"");
out.append(Editor.LOGIN_USER);
out.append("\"");
 if(failureUser!=null){out.append(" value=\"");
out.append(encode(failureUser));
out.append("\"");
} out.append("></td>\n" +
	"\t\t\t\t</tr>\n" +
	"\t\t\t\t<tr>\n" +
	"\t\t\t\t\t<td>Password</td>\n" +
	"\t\t\t\t\t<td><input name=\"");
out.append(Editor.LOGIN_PASSWORD);
out.append("\" type=\"password\"></td>\n" +
	"\t\t\t\t</tr>\n" +
	"\t\t\t\t<tr>\n" +
	"\t\t\t\t\t<td></td>\n" +
	"\t\t\t\t\t<td><input name=\"");
out.append(Editor.LOGIN_SUBMIT);
out.append("\" type=\"submit\" value=\"Login\"></td>\n" +
	"\t\t\t\t</tr>\n" +
	"\t\t\t</table>\n" +
	"\t\t</form>\n" +
	"\t\t<div class=\"footer\">\n" +
	"\t\t\t");
out.append(encode(thePackage.getSpecificationTitle()));
out.append("\n" +
	"\t\t\t");
out.append(encode(thePackage.getSpecificationVersion()));
out.append("\n" +
	"\t\t</div>\n" +
	"\t</body>\n" +
	"</html>");

	}
}

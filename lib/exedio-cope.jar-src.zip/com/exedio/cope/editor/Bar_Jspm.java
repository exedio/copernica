
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope.editor;

import static com.exedio.cops.XMLEncoder.encode;
import static com.exedio.cope.editor.Editor.AVOID_COLLISION;

import java.util.ArrayList;

final class Bar_Jspm
{
	private static final String ID_LINE_FORM    = AVOID_COLLISION + "barLineForm";
	private static final String ID_LINE_FEATURE = AVOID_COLLISION + "barLineFeature";
	private static final String ID_LINE_ITEM    = AVOID_COLLISION + "barLineItem";
	private static final String ID_LINE_VALUE   = AVOID_COLLISION + "barLineValue";
	private static final String ID_LINE_APPLY   = AVOID_COLLISION + "barLineApply";
	private static final String ID_LINE_PUBLISH = AVOID_COLLISION + "barLinePublish";
	
	private static final String ID_FILE_FORM    = AVOID_COLLISION + "barFileForm";
	private static final String ID_FILE_FEATURE = AVOID_COLLISION + "barFileFeature";
	private static final String ID_FILE_ITEM    = AVOID_COLLISION + "barFileItem";
	private static final String ID_FILE_VALUE   = AVOID_COLLISION + "barFileValue";
	private static final String ID_FILE_APPLY   = AVOID_COLLISION + "barFileApply";
	private static final String ID_FILE_PUBLISH = AVOID_COLLISION + "barFilePublish";
	
	private static final String ID_AREA_FORM    = AVOID_COLLISION + "barAreaForm";
	private static final String ID_AREA_FEATURE = AVOID_COLLISION + "barAreaFeature";
	private static final String ID_AREA_ITEM    = AVOID_COLLISION + "barAreaItem";
	private static final String ID_AREA_VALUE   = AVOID_COLLISION + "barAreaValue";
	private static final String ID_AREA_APPLY   = AVOID_COLLISION + "barAreaApply";
	private static final String ID_AREA_PUBLISH = AVOID_COLLISION + "barAreaPublish";
	
	private static final String ONKEY_METHOD_LINE = AVOID_COLLISION + "onkeyline";
	
	static final void writeHead(
			final StringBuilder out,
			final boolean borders)
	{
		out.append("\n" +
	"\t\t<style type=\"text/css\">\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar\n" +
	"\t\t\t{\n" +
	"\t\t\t\tposition: fixed; top: 20px; min-width: 350px;\n" +
	"\t\t\t\tz-index: 1;\n" +
	"\t\t\t\tborder: outset 4px #f0f8ff;\n" +
	"\t\t\t\tbackground: #f0f8ff;\n" +
	"\t\t\t\tpadding: 5px;\n" +
	"\t\t\t\ttext-align: left;\n" +
	"\t\t\t\tfont-size: 10pt;\n" +
	"\t\t\t\tcolor: #002;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar h1\n" +
	"\t\t\t{\n" +
	"\t\t\t\tmargin: 0px;\n" +
	"\t\t\t\tborder: 0px;\n" +
	"\t\t\t\tpadding: 0px;\n" +
	"\t\t\t\tfont-size: 12pt;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar h1 a\n" +
	"\t\t\t{\n" +
	"\t\t\t\tcolor: #000;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar a\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-decoration: none;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar input\n" +
	"\t\t\t{\n" +
	"\t\t\t\tbackground: #f0f8ff;\n" +
	"\t\t\t\tfont-size: 80%;\n" +
	"\t\t\t\tcolor: #002;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar select\n" +
	"\t\t\t{\n" +
	"\t\t\t\tbackground: #f0f8ff;\n" +
	"\t\t\t\tfont-size: 80%;\n" +
	"\t\t\t\tcolor: #002;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tform#contentEditorBarSwitches\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfloat: right;\n" +
	"\t\t\t}");

		
		if(borders)
		{
		out.append("\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar hr\n" +
	"\t\t\t{\n" +
	"\t\t\t\theight: 0px;\n" +
	"\t\t\t\tmargin: 1em 0px;\n" +
	"\t\t\t\tborder-width: 0px;\n" +
	"\t\t\t\tborder-top: 1px solid #99d;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar input.text\n" +
	"\t\t\t{\n" +
	"\t\t\t\twidth: 80%;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\tdiv#contentEditorBar input.publishNow\n" +
	"\t\t\t{\n" +
	"\t\t\t\tbackground: #f0d8df;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg#");
out.append(ID_FILE_VALUE);
out.append("\n" +
	"\t\t\t{\n" +
	"\t\t\t\tmargin: 0px;\n" +
	"\t\t\t\tfloat: right;\n" +
	"\t\t\t\tborder: solid #ccd 5px;\n" +
	"\t\t\t\theight: 40px;\n" +
	"\t\t\t}");

		
		}
		out.append("\n" +
	"\t\t\t\n" +
	"\t\t</style>");

		
		if(borders)
		{
		out.append("\n" +
	"\t\t<script>\n" +
	"\t\t\tvar previousBorder = null;\n" +
	"\t\t\tvar previousModifiable = false;\n" +
	"\t\t\t\n" +
	"\t\t\tfunction ");
out.append(Editor.EDIT_METHOD_LINE);
out.append("(border,feature,item,value,modifiable)\n" +
	"\t\t\t{\n" +
	"\t\t\t\tif(previousBorder==border)\n" +
	"\t\t\t\t\treturn true;\n" +
	"\t\t\t\t\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_FORM);
out.append("\").style.display = \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_FORM);
out.append("\").style.display = \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_VALUE);
out.append("\").value = null;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_VALUE);
out.append("\").firstChild.data = null;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_FEATURE);
out.append("\").value = feature;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_ITEM   );
out.append("\").value = item;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_VALUE  );
out.append("\").value = value;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_APPLY  );
out.append("\").style.display = modifiable ? \"inline\" : \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_PUBLISH);
out.append("\").style.display = modifiable ? \"none\" : \"inline\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_FORM);
out.append("\").style.display = \"inline\";\n" +
	"\t\t\t\tdocument.getElementById(\"contentEditorBar\").style.display = \"block\";\n" +
	"\t\t\t\t\n" +
	"\t\t\t\tif(previousBorder!=null)\n" +
	"\t\t\t\t\tpreviousBorder.className='contentEditorLink';\n" +
	"\t\t\t\tborder.className='contentEditorLinkEdited';\n" +
	"\t\t\t\tpreviousBorder = border;\n" +
	"\t\t\t\tpreviousModifiable = modifiable;\n" +
	"\t\t\t\t\n" +
	"\t\t\t\treturn false;\n" +
	"\t\t\t}\n" +
	"\t\t\tfunction ");
out.append(Editor.EDIT_METHOD_FILE);
out.append("(border,feature,item,value,modifiable)\n" +
	"\t\t\t{\n" +
	"\t\t\t\tif(previousBorder==border)\n" +
	"\t\t\t\t\treturn true;\n" +
	"\t\t\t\t\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_FORM);
out.append("\").style.display = \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_FORM);
out.append("\").style.display = \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_VALUE);
out.append("\").value = null;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_VALUE);
out.append("\").firstChild.data = null;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_FEATURE);
out.append("\").value = feature;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_ITEM   );
out.append("\").value = item;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_VALUE);
out.append("\").src = value;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_APPLY  );
out.append("\").style.display = modifiable ? \"inline\" : \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_PUBLISH);
out.append("\").style.display = modifiable ? \"none\" : \"inline\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_FORM);
out.append("\").style.display = \"inline\";\n" +
	"\t\t\t\tdocument.getElementById(\"contentEditorBar\").style.display = \"block\";\n" +
	"\t\t\t\t\n" +
	"\t\t\t\tif(previousBorder!=null)\n" +
	"\t\t\t\t\tpreviousBorder.className='contentEditorLink';\n" +
	"\t\t\t\tborder.className='contentEditorLinkEdited';\n" +
	"\t\t\t\tpreviousBorder = border;\n" +
	"\t\t\t\tpreviousModifiable = modifiable;\n" +
	"\t\t\t\t\n" +
	"\t\t\t\treturn false;\n" +
	"\t\t\t}\n" +
	"\t\t\tfunction ");
out.append(Editor.EDIT_METHOD_AREA);
out.append("(border,feature,item,value,modifiable)\n" +
	"\t\t\t{\n" +
	"\t\t\t\tif(previousBorder==border)\n" +
	"\t\t\t\t\treturn true;\n" +
	"\t\t\t\t\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_FORM);
out.append("\").style.display = \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_FORM);
out.append("\").style.display = \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_LINE_VALUE);
out.append("\").value = null;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_FILE_VALUE);
out.append("\").value = null;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_FEATURE);
out.append("\").value = feature;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_ITEM   );
out.append("\").value = item;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_VALUE  );
out.append("\").firstChild.data = value;\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_APPLY  );
out.append("\").style.display = modifiable ? \"inline\" : \"none\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_PUBLISH);
out.append("\").style.display = modifiable ? \"none\" : \"inline\";\n" +
	"\t\t\t\tdocument.getElementById(\"");
out.append(ID_AREA_FORM);
out.append("\").style.display = \"inline\";\n" +
	"\t\t\t\tdocument.getElementById(\"contentEditorBar\").style.display = \"block\";\n" +
	"\t\t\t\t\n" +
	"\t\t\t\tif(previousBorder!=null)\n" +
	"\t\t\t\t\tpreviousBorder.className='contentEditorLink';\n" +
	"\t\t\t\tborder.className='contentEditorLinkEdited';\n" +
	"\t\t\t\tpreviousBorder = border;\n" +
	"\t\t\t\tpreviousModifiable = modifiable;\n" +
	"\t\t\t\t\n" +
	"\t\t\t\treturn false;\n" +
	"\t\t\t}\n" +
	"\t\t\tfunction ");
out.append(ONKEY_METHOD_LINE);
out.append("(line)\n" +
	"\t\t\t{\n" +
	"\t\t\t\tif(previousBorder==null || !previousModifiable)\n" +
	"\t\t\t\t\treturn true;\n" +
	"\t\t\t\tpreviousBorder.innerHTML = line.value;\n" +
	"\t\t\t\treturn true;\n" +
	"\t\t\t}\n" +
	"\t\t</script>");

		}
	}
	
	static final void write(
			final StringBuilder out,
			final Target target,
			final ArrayList<Target> targets,
			final String action,
			final String referer,
			final boolean borders,
			final String borderToggleParameter,
			final String borderButtonURL,
			final String hideButtonURL,
			final String closeButtonURL,
			final int modificationsCount,
			final String loginName)
	{
		out.append("\n" +
	"\t\t<div id=\"contentEditorBar\" style=\"right:20px;\">\n" +
	"\t\t\t<form action=\"");
out.append(action);
out.append("\" method=\"POST\" id=\"contentEditorBarSwitches\">\n" +
	"\t\t\t\t<input type=\"hidden\" name=\"");
out.append(Editor.BAR_REFERER);
out.append("\" value=\"");
out.append(referer);
out.append("\">\n" +
	"\t\t\t\t<input type=\"");

					if(borderButtonURL!=null) { out.append("image");
 } else { out.append("submit");
 }
					out.append("\" name=\"");
out.append(borderToggleParameter);
out.append("\" ");

					if(borderButtonURL!=null)
					{ out.append("src=\"");
out.append(borderButtonURL);
out.append("\" alt=\"");
if(borders){out.append("Dis");
}else{out.append("En");
}out.append("able Borders\"");
 }
					else
					{ out.append("value=\"");
if(borders){out.append("dis");
}else{out.append("en");
}out.append("able borders\"");
 }
					out.append(">\n" +
	"\t\t\t\t<img src=\"");
out.append(hideButtonURL);
out.append("\" onclick=\"document.getElementById('contentEditorBar').style.display = 'none';\">\n" +
	"\t\t\t\t<input type=\"");

					if(closeButtonURL!=null) { out.append("image");
 } else { out.append("submit");
 }
					out.append("\" name=\"");
out.append(Editor.BAR_CLOSE);
out.append("\" ");

					if(closeButtonURL!=null)
					{ out.append("src=\"");
out.append(closeButtonURL);
out.append("\" alt=\"Close Live Edit\"");
 }
					else
					{ out.append("value=\"X\"");
 }
					out.append(">\n" +
	"\t\t\t</form>\n" +
	"\t\t\t<h1><a href=\"");
out.append(action);
out.append("?");
out.append(Editor.PREVIEW_OVERVIEW);
out.append("=t\" target=\"Live Edit\">COPE Live Edit</a></h1>");

			if(loginName!=null)
			{
			out.append("\n" +
	"\t\t\tlogged in as ");
out.append(encode(loginName));

			}
			out.append("\n" +
	"\t\t\t<br>\n" +
	"\t\t\t<form action=\"");
out.append(action);
out.append("\" method=\"POST\" style=\"display:inline;\">\n" +
	"\t\t\t\t<input type=\"hidden\" name=\"");
out.append(Editor.BAR_REFERER);
out.append("\" value=\"");
out.append(referer);
out.append("\">\n" +
	"\t\t\t\t<select name=\"");
out.append(Editor.BAR_SWITCH_TARGET);
out.append("\" onchange=\"this.form.submit();\">");

				for(final Target t : targets)
				{
					final boolean active = t.equals(target);
					out.append("\n" +
	"\t\t\t\t\t<option value=\"");
out.append(t.getID());
out.append("\"");

						if(active){out.append(" selected=\"selected\"");
}
						out.append(">");
out.append(t.getDescription());
out.append("</option>");

				}
				out.append("\n" +
	"\t\t\t\t</select>\n" +
	"\t\t\t</form>");

			
			if(modificationsCount>0)
			{
				final boolean live = target.isLive();
			out.append("\n" +
	"\t\t\t<form action=\"");
out.append(action);
out.append("\" method=\"POST\" style=\"display:inline;\">\n" +
	"\t\t\t\t<input type=\"hidden\" name=\"");
out.append(Editor.BAR_REFERER    );
out.append("\" value=\"");
out.append(referer);
out.append("\">\n" +
	"\t\t\t\t<input type=\"submit\" name=\"");
out.append(Editor.BAR_SAVE_TARGET);
out.append("\" value=\"");
 if(live){out.append("Publish");
}else{out.append("Save");
} 
					if(modificationsCount>1)
					{
						out.append(" (");
out.append(modificationsCount);
out.append(")");

					}
					out.append("\" style=\"padding:0px;\"");

					if(live)
					{
						out.append(" onclick=\"return confirm('Do you really want to publish ");
out.append(
						modificationsCount
						);
out.append(" modification(s) directly to the live web site?\\n\\nYou cannot undo this operation.')\"");

					}
					out.append(">\n" +
	"\t\t\t</form>");

			}
			out.append("\n" +
	"\t\t\t<br clear=\"both\">");

			if(borders)
			{
			out.append("\n" +
	"\t\t\t<form action=\"");
out.append(action);
out.append("\" method=\"POST\" id=\"");
out.append(ID_LINE_FORM);
out.append("\" style=\"display:none;\">\n" +
	"\t\t\t\t<hr>\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_REFERER);
out.append("\" value=\"");
out.append(referer     );
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_FEATURE);
out.append("\" id=\"");
out.append(ID_LINE_FEATURE);
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_ITEM   );
out.append("\" id=\"");
out.append(ID_LINE_ITEM   );
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_TEXT   );
out.append("\" id=\"");
out.append(ID_LINE_VALUE  );
out.append("\" class=\"text\" onkeyup=\"return ");
out.append(ONKEY_METHOD_LINE);
out.append("(this);\">\n" +
	"\t\t\t\t<br>\n" +
	"\t\t\t\t<input type=\"submit\" value=\"Publish Now!\" id=\"");
out.append(ID_LINE_PUBLISH);
out.append("\" name=\"");
out.append(Editor.BAR_PUBLISH_NOW);
out.append("\" class=\"publishNow\">\n" +
	"\t\t\t\t<input type=\"submit\" value=\"Apply\"        id=\"");
out.append(ID_LINE_APPLY);
out.append("\">\n" +
	"\t\t\t</form>\n" +
	"\t\t\t<form action=\"");
out.append(action);
out.append("\" method=\"POST\" id=\"");
out.append(ID_FILE_FORM);
out.append("\" style=\"display:none;\" enctype=\"multipart/form-data\">\n" +
	"\t\t\t\t<hr>\n" +
	"\t\t\t\t<img id=\"");
out.append(ID_FILE_VALUE);
out.append("\" src=\"\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_REFERER);
out.append("\" value=\"");
out.append(referer     );
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_FEATURE);
out.append("\" id=\"");
out.append(ID_FILE_FEATURE);
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_ITEM   );
out.append("\" id=\"");
out.append(ID_FILE_ITEM   );
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_FILE   );
out.append("\" type=\"file\" class=\"text\">\n" +
	"\t\t\t\t<br>\n" +
	"\t\t\t\t<input type=\"submit\" value=\"Publish Now!\" id=\"");
out.append(ID_FILE_PUBLISH);
out.append("\" name=\"");
out.append(Editor.BAR_PUBLISH_NOW);
out.append("\" class=\"publishNow\">\n" +
	"\t\t\t\t<input type=\"submit\" value=\"Apply\"        id=\"");
out.append(ID_FILE_APPLY);
out.append("\">\n" +
	"\t\t\t\t<br>\n" +
	"\t\t\t</form>\n" +
	"\t\t\t<form action=\"");
out.append(action);
out.append("\" method=\"POST\" id=\"");
out.append(ID_AREA_FORM);
out.append("\" style=\"display:none;\">\n" +
	"\t\t\t\t<hr>\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_REFERER);
out.append("\" value=\"");
out.append(referer     );
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_FEATURE);
out.append("\" id=\"");
out.append(ID_AREA_FEATURE);
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<input name=\"");
out.append(   Editor.BAR_ITEM   );
out.append("\" id=\"");
out.append(ID_AREA_ITEM   );
out.append("\" type=\"hidden\">\n" +
	"\t\t\t\t<textarea name=\"");
out.append(Editor.BAR_TEXT   );
out.append("\" id=\"");
out.append(ID_AREA_VALUE  );
out.append("\" cols=\"100\" rows=\"15\">X</textarea>\n" +
	"\t\t\t\t<input type=\"submit\" value=\"Publish Now!\" id=\"");
out.append(ID_AREA_PUBLISH);
out.append("\" name=\"");
out.append(Editor.BAR_PUBLISH_NOW);
out.append("\" class=\"publishNow\">\n" +
	"\t\t\t\t<input type=\"submit\" value=\"Apply\"        id=\"");
out.append(ID_AREA_APPLY);
out.append("\">\n" +
	"\t\t\t</form>");

			}
			out.append("\n" +
	"\t\t</div>");

	}
}

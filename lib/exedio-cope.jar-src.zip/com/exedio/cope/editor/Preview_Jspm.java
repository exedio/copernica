
/*
 * Copyright (C) 2004-2008  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope.editor;

import static com.exedio.cops.XMLEncoder.encode;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

final class Preview_Jspm
{
	static final void writeOverview(
			final StringBuilder out,
			final HttpServletRequest request,
			final HttpServletResponse response,
			final String url,
			final Set<Modification> modifications,
			final Target activeTarget,
			final List<Target> targets,
			final String activeAuthor,
			final boolean draftsEnabled,
			final List<Draft> drafts)
	{
out.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"  \"http://www.w3.org/TR/html4/loose.dtd\">\n" +
	"<html>\n" +
	"\t<head>\n" +
	"\t\t<meta http-equiv=\"content-type\" content=\"text/html; charset=");
out.append(Editor.UTF8);
out.append("\">\n" +
	"\t\t<title>Live Edit</title>\n" +
	"\t\t<style>\n" +
	"\t\t\th1\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-family:sans-serif;\n" +
	"\t\t\t\tfont-size:180%;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg\n" +
	"\t\t\t{\n" +
	"\t\t\t\tborder:0;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\timg.logo\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfloat:right;\n" +
	"\t\t\t\twidth:198px;\n" +
	"\t\t\t\theight:60px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable caption\n" +
	"\t\t\t{\n" +
	"\t\t\t\tfont-style:italic;\n" +
	"\t\t\t\ttext-align:left;\n" +
	"\t\t\t\twhite-space:nowrap;\n" +
	"\t\t\t\tbackground:#ccc;\n" +
	"\t\t\t\tpadding:1px 5px;\n" +
	"\t\t\t\tborder:solid 2px white;\n" +
	"\t\t\t\tborder-bottom-width:0px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable th\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-align:left;\n" +
	"\t\t\t\tvertical-align:top;\n" +
	"\t\t\t\tbackground:#ccc;\n" +
	"\t\t\t\tborder:solid 1px #ccc;\n" +
	"\t\t\t\tpadding:1px 3px;\n" +
	"\t\t\t\tfont-weight:normal;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable td\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-align:left;\n" +
	"\t\t\t\tvertical-align:top;\n" +
	"\t\t\t\tborder:solid 1px #ccc;\n" +
	"\t\t\t\tpadding:1px 3px;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable td.number\n" +
	"\t\t\t{\n" +
	"\t\t\t\ttext-align:right;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\ttable tr.open td\n" +
	"\t\t\t{\n" +
	"\t\t\t\tbackground-color:#bbd;\n" +
	"\t\t\t\tborder-color:#bbd;\n" +
	"\t\t\t}\n" +
	"\t\t\t\n" +
	"\t\t\thr\n" +
	"\t\t\t{\n" +
	"\t\t\t\theight:0px;\n" +
	"\t\t\t\tmargin:1em 0px;\n" +
	"\t\t\t\tborder-width:0px;\n" +
	"\t\t\t\tborder-top:1px solid #999;\n" +
	"\t\t\t}\n" +
	"\t\t</style>\n" +
	"\t</head>\n" +
	"\t<body>\n" +
	"\t\t<a href=\"http://cope.sourceforge.net/\" target=\"_blank\"><img src=\"http://cope.sourceforge.net/exedio.png\" alt=\"Exedio Logo\" class=\"logo\"></a>\n" +
	"\t\t<h1>COPE Live Edit</h1>");

		
	if(draftsEnabled)
	{
		out.append("\n" +
	"\t\t<table>\n" +
	"\t\t\t<tr>\n" +
	"\t\t\t\t<th></th>\n" +
	"\t\t\t\t<th>Date</th>\n" +
	"\t\t\t\t<th>Author</th>\n" +
	"\t\t\t\t<th>Comment</th>\n" +
	"\t\t\t\t<th>Items</th>\n" +
	"\t\t\t\t<th></th>\n" +
	"\t\t\t</tr>");

			for(final Target target : targets)
			{
				final boolean open = activeTarget.equals(target);
				final boolean live = target.isLive();
			out.append("\n" +
	"\t\t\t<tr");
 if(open){out.append(" class=\"open\"");
} out.append(">\n" +
	"\t\t\t\t<td>\n" +
	"\t\t\t\t\t<form action=\"");
out.append(url);
out.append("\" method=\"POST\" style=\"display:inline;\">\n" +
	"\t\t\t\t\t\t<input type=\"hidden\" name=\"");
out.append(Editor.TARGET_ID);
out.append("\"   value=\"");
out.append(target.getID());
out.append("\">\n" +
	"\t\t\t\t\t\t<input type=\"submit\" name=\"");
out.append(Editor.TARGET_OPEN);
out.append("\" value=\"Open\"");
 if(open){out.append(" disabled=\"disabled\"");
} out.append(">\n" +
	"\t\t\t\t\t</form>\n" +
	"\t\t\t\t</td>");

			if(live)
			{
				out.append("\n" +
	"\t\t\t\t<td colspan=\"5\">");
out.append(target.getDescription());
out.append("</td>");

			}
			else
			{
				final Draft draft = ((TargetDraft)target).draft;
				final int itemsCount = draft.getItemsCount();
				out.append("\n" +
	"\t\t\t\t<td>");
out.append(draft.getDate());
out.append("</td>\n" +
	"\t\t\t\t<td>");
out.append(draft.getAuthor());
out.append("</td>\n" +
	"\t\t\t\t<td>");
out.append(draft.getComment());
out.append("</td>\n" +
	"\t\t\t\t<td class=\"number\">");
out.append(itemsCount);
out.append("</td>");

				out.append("\n" +
	"\t\t\t\t<td>\n" +
	"\t\t\t\t\t<form action=\"");
out.append(url);
out.append("\" method=\"POST\" style=\"display:inline;\">\n" +
	"\t\t\t\t\t\t<input type=\"hidden\" name=\"");
out.append(Editor.DRAFT_ID    );
out.append("\" value=\"");
out.append(target.getID());
out.append("\">\n" +
	"\t\t\t\t\t\t<input type=\"submit\" name=\"");
out.append(Editor.DRAFT_LOAD  );
out.append("\" value=\"Load\">\n" +
	"\t\t\t\t\t\t<input type=\"submit\" name=\"");
out.append(Editor.DRAFT_DELETE);
out.append("\" value=\"Delete\"");

							if(itemsCount>0)
							{
								out.append(" onclick=\"return confirm('Do you really want to delete ");
out.append(
								encode(target.getDescription())
								);
out.append("? It contains ");
out.append(
								itemsCount
								);
out.append(" item(s).\\n\\nYou cannot undo this operation.')\"");

							}
						out.append(">\n" +
	"\t\t\t\t\t</form>\n" +
	"\t\t\t\t</td>");

			}
			out.append("\n" +
	"\t\t\t</tr>");

			}
		out.append("\n" +
	"\t\t\t<tr>\n" +
	"\t\t\t\t<form action=\"");
out.append(url);
out.append("\" method=\"POST\">\n" +
	"\t\t\t\t\t<td></td>\n" +
	"\t\t\t\t\t<td></td>\n" +
	"\t\t\t\t\t<td>");
out.append(activeAuthor);
out.append("</td>\n" +
	"\t\t\t\t\t<td><input name=\"");
out.append(Editor.DRAFT_COMMENT);
out.append("\" type=\"text\"></td>\n" +
	"\t\t\t\t\t<td></td>\n" +
	"\t\t\t\t\t<td><input type=\"submit\" name=\"");
out.append(Editor.DRAFT_NEW);
out.append("\" value=\"New\"></td>\n" +
	"\t\t\t\t</form>\n" +
	"\t\t\t</tr>\n" +
	"\t\t</table>\n" +
	"\t\t<hr>");

	}
	
	if(modifications.isEmpty())
	{
		out.append("\n" +
	"\t\t<div>There are no unsaved modifications in this Live Edit session.</div>");

	}
	else
	{
		out.append("\n" +
	"\t\t<form action=\"");
out.append(url);
out.append("\" method=\"POST\">\n" +
	"\t\t\t<table>\n" +
	"\t\t\t\t<caption>Modifications</caption>\n" +
	"\t\t\t\t<tr>\n" +
	"\t\t\t\t\t<th></th>\n" +
	"\t\t\t\t\t<th>Old</th>\n" +
	"\t\t\t\t\t<th>New</th>\n" +
	"\t\t\t\t</tr>");

				
				for(final Modification m : modifications)
				{
				out.append("\n" +
	"\t\t\t\t<tr>\n" +
	"\t\t\t\t\t<td><input name=\"");
out.append(Editor.MODIFICATION_IDS);
out.append("\" type=\"checkbox\" value=\"");
out.append(m.getID());
out.append("\" checked=\"checked\"></td>\n" +
	"\t\t\t\t");

				if(m instanceof ModificationString)
				{
					final ModificationString ms = (ModificationString)m;
					out.append("\n" +
	"\t\t\t\t\t<td>");
out.append(ms.getOldValue());
out.append("</td>\n" +
	"\t\t\t\t\t<td>");
out.append(ms.value);
out.append("</td>");

				}
				else
				{
					final ModificationMedia mm = (ModificationMedia)m;
					final String u = encode(mm.getURL(request, response));
					out.append("\n" +
	"\t\t\t\t\t<td colspan=\"2\"><a href=\"");
out.append(u);
out.append("\"><img src=\"");
out.append(u);
out.append("\" height=\"50\"></a></td>");

				}
				out.append("\n" +
	"\t\t\t\t</tr>");

				}
				out.append("\n" +
	"\t\t\t</table>\n" +
	"\t\t\t<input name=\"");
out.append(Editor.MODIFICATION_PUBLISH);
out.append("\" type=\"submit\" value=\"Publish\">\n" +
	"\t\t\t<input name=\"");
out.append(Editor.MODIFICATION_DISCARD);
out.append("\" type=\"submit\" value=\"Discard\">");

			
		if(draftsEnabled)
		{
			out.append("\n" +
	"\t\t\t<br>\n" +
	"\t\t\t<input name=\"");
out.append(Editor.MODIFICATION_PERSIST);
out.append("\" type=\"submit\" value=\"Save as new Draft:\">\n" +
	"\t\t\t<input name=\"");
out.append(Editor.MODIFICATION_PERSIST_COMMENT);
out.append("\" type=\"text\">");

			
			if(!drafts.isEmpty())
			{
			out.append("\n" +
	"\t\t\t<br>\n" +
	"\t\t\t<input name=\"");
out.append(Editor.SAVE_TO_DRAFT);
out.append("\" type=\"submit\" value=\"Save to Draft:\">\n" +
	"\t\t\t<select name=\"");
out.append(Editor.DRAFT_ID);
out.append("\">");

			for(final Draft draft : drafts)
			{
				out.append("\n" +
	"\t\t\t\t<option value=\"");
out.append(draft.getCopeID());
out.append("\">");
out.append(draft.getDropDownSummary());
out.append("</option>");

			}
			out.append("\n" +
	"\t\t\t</select>");

			}
		}
		out.append("\n" +
	"\t\t</form>");

	}
	out.append("\n" +
	"\t</body>\n" +
	"</html>");

	}
}
